// Random number to guess
num = Math.random() * Number.MAX_SAFE_INTEGER;

// Guess
guess = 1;
var upper;
var lower;

while(guess < num){
  guess = guess * 2;
}

upper = guess;
lower = Math.floor(guess/2);

while(guess != num){
  guess = Math.floor((upper + lower) / 2);
  if(guess < num){
    lower = guess;
  }
  if (guess > num){
    upper = guess;
  }
}

// Print output to console
console.log("Guess: " + guess + "\nNum: " + num);
if(guess == num){
  console.log("Success!");
}